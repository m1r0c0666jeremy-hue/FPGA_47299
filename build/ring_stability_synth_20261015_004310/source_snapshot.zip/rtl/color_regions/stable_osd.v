// Generated upright UI. Source geometry is mapped through the committed view.
// One shared decimal converter formats the selected footer before row624.
`default_nettype none
module stable_osd(
 input wire I_clk,I_rst_n,I_vs,I_hs,I_de,input wire [23:0] I_rgb,
 input wire [639:0] I_meta,input wire [10:0] I_x0,input wire [9:0] I_y0,
 input wire [1:0] I_zoom,I_mode,input wire [2:0] I_state,
 input wire I_tracking,I_show,I_video_ok,I_pair,I_detection_valid,I_sample_valid,
 output reg O_vs,O_hs,O_de,output reg [23:0] O_rgb,
 input wire I_rotate,input wire [1:0] I_diag,input wire [31:0] I_image_id
);
 localparam FONT=24,COLS=46;
 reg [10:0] x;reg [9:0] y;reg vs_last;
 reg [639:0] fm;reg [31:0] fimage;reg [1:0] fmode,fzoom,fdiag;
 reg [2:0] fstate;reg fpair,frotate,ftracking,fshow,fvideo,fdetection,fsample;
 reg [4:0] status_id;
 always @*begin
 status_id=!ftracking?0:{1'b0,fm[36:33]};
 if(fm[568])status_id=15;
 if(fm[567:565]!=0)begin
 case(fm[567:565])1:status_id=9;2:status_id=10;3:status_id=11;4:status_id=12;default:status_id=9;endcase
 if(fm[564])status_id=13;if(fm[563:560]!=0)status_id=14;end
 if(ftracking && !fm[255])status_id=19;
 if(fm[255] && !fm[247])status_id=8;
 if(fstate==7)status_id=18;if(fstate==5)status_id=17;if(!fvideo || fstate==6)status_id=16;
 end
 function [19:0] field_value;input [4:0] id;begin
 case(id)
 0:field_value=fm[203:184];1:field_value=fm[223:204];
 2:field_value=fm[275:256];3:field_value=fm[315:296];4:field_value=fm[295:276];5:field_value=fm[335:316];
 6:field_value=fm[356:350];7:field_value=fm[363:357];
 8:field_value=fm[478:470];9:field_value=fm[469:461];10:field_value=fm[460:453];11:field_value=fm[452:445];
 12:field_value=fm[542:534];13:field_value=fm[533:525];14:field_value=fm[524:517];15:field_value=fm[516:509];
 16:field_value=fm[592:581];17:field_value=fm[580:569];
 18:field_value=fm[407:400];19:field_value=fm[399:392];20:field_value=fm[391:384];
 21:field_value=fm[383:380];22:field_value=fm[624:607];23:field_value=fm[639:625];default:field_value=0;
 endcase end endfunction
 reg [23:0] numbers[0:23];reg [7:0] characters[0:127];
 reg [1:0] format_state;reg [4:0] field_index,bit_index;
 reg [19:0] binary;reg [23:0] decimal,adjusted;reg [5:0] format_col;reg format_row,footer_ready;
 integer nibble;
 always @*begin adjusted=decimal;for(nibble=0;nibble<6;nibble=nibble+1)
 if(decimal[nibble*4+:4]>=5)adjusted[nibble*4+:4]=decimal[nibble*4+:4]+3;end
function [7:0] mode_char;input [4:0] id;input [5:0] pos;begin mode_char=0;case(id)
0:case(pos)
0:mode_char=8'd128;
1:mode_char=8'd129;
endcase
1:case(pos)
0:mode_char=8'd48;
1:mode_char=8'd130;
2:mode_char=8'd131;
3:mode_char=8'd112;
endcase
2:case(pos)
0:mode_char=8'd132;
1:mode_char=8'd113;
endcase
3:case(pos)
0:mode_char=8'd48;
1:mode_char=8'd130;
2:mode_char=8'd133;
3:mode_char=8'd134;
endcase
endcase end endfunction
function [7:0] status_char;input [4:0] id;input [5:0] pos;begin status_char=0;case(id)
0:case(pos)
0:status_char=8'd37;
1:status_char=8'd38;
endcase
1:case(pos)
0:status_char=8'd39;
1:status_char=8'd40;
2:status_char=8'd41;
3:status_char=8'd42;
endcase
2:case(pos)
0:status_char=8'd43;
1:status_char=8'd44;
2:status_char=8'd39;
endcase
3:case(pos)
0:status_char=8'd45;
1:status_char=8'd46;
2:status_char=8'd39;
endcase
4:case(pos)
0:status_char=8'd47;
1:status_char=8'd48;
endcase
5:case(pos)
0:status_char=8'd49;
1:status_char=8'd50;
2:status_char=8'd51;
3:status_char=8'd52;
endcase
6:case(pos)
0:status_char=8'd39;
1:status_char=8'd40;
2:status_char=8'd53;
3:status_char=8'd41;
endcase
7:case(pos)
0:status_char=8'd54;
1:status_char=8'd55;
2:status_char=8'd56;
3:status_char=8'd57;
endcase
8:case(pos)
0:status_char=8'd58;
1:status_char=8'd59;
2:status_char=8'd60;
endcase
9:case(pos)
0:status_char=8'd61;
1:status_char=8'd62;
2:status_char=8'd63;
3:status_char=8'd64;
endcase
10:case(pos)
0:status_char=8'd65;
1:status_char=8'd66;
2:status_char=8'd67;
3:status_char=8'd63;
4:status_char=8'd64;
endcase
11:case(pos)
0:status_char=8'd11;
1:status_char=8'd48;
2:status_char=8'd63;
3:status_char=8'd64;
endcase
12:case(pos)
0:status_char=8'd12;
1:status_char=8'd48;
2:status_char=8'd63;
3:status_char=8'd64;
endcase
13:case(pos)
0:status_char=8'd68;
1:status_char=8'd69;
2:status_char=8'd70;
3:status_char=8'd71;
4:status_char=8'd39;
endcase
14:case(pos)
0:status_char=8'd68;
1:status_char=8'd69;
2:status_char=8'd49;
3:status_char=8'd72;
endcase
15:case(pos)
0:status_char=8'd73;
1:status_char=8'd53;
2:status_char=8'd74;
3:status_char=8'd63;
4:status_char=8'd64;
endcase
16:case(pos)
0:status_char=8'd75;
1:status_char=8'd76;
2:status_char=8'd77;
3:status_char=8'd78;
4:status_char=8'd79;
endcase
17:case(pos)
0:status_char=8'd80;
1:status_char=8'd81;
2:status_char=8'd82;
3:status_char=8'd83;
endcase
18:case(pos)
0:status_char=8'd58;
1:status_char=8'd74;
2:status_char=8'd60;
endcase
19:case(pos)
0:status_char=8'd84;
1:status_char=8'd37;
2:status_char=8'd85;
3:status_char=8'd86;
endcase
endcase end endfunction
function [7:0] help_char;input [4:0] id;input [5:0] pos;begin help_char=0;case(id)
1:case(pos)
0:help_char=8'd39;
1:help_char=8'd40;
2:help_char=8'd61;
3:help_char=8'd62;
4:help_char=8'd0;
5:help_char=8'd21;
6:help_char=8'd15;
7:help_char=8'd35;
8:help_char=8'd4;
9:help_char=8'd68;
10:help_char=8'd69;
11:help_char=8'd0;
12:help_char=8'd21;
13:help_char=8'd15;
14:help_char=8'd35;
15:help_char=8'd3;
16:help_char=8'd42;
17:help_char=8'd119;
endcase
2:case(pos)
0:help_char=8'd120;
1:help_char=8'd121;
2:help_char=8'd122;
3:help_char=8'd123;
4:help_char=8'd0;
5:help_char=8'd51;
6:help_char=8'd52;
7:help_char=8'd66;
8:help_char=8'd67;
9:help_char=8'd0;
10:help_char=8'd21;
11:help_char=8'd15;
12:help_char=8'd35;
13:help_char=8'd4;
14:help_char=8'd68;
15:help_char=8'd69;
16:help_char=8'd0;
17:help_char=8'd21;
18:help_char=8'd15;
19:help_char=8'd35;
20:help_char=8'd3;
21:help_char=8'd42;
22:help_char=8'd119;
endcase
3:case(pos)
0:help_char=8'd11;
1:help_char=8'd124;
2:help_char=8'd54;
3:help_char=8'd55;
4:help_char=8'd48;
5:help_char=8'd125;
6:help_char=8'd64;
7:help_char=8'd39;
8:help_char=8'd40;
9:help_char=8'd0;
10:help_char=8'd21;
11:help_char=8'd15;
12:help_char=8'd35;
13:help_char=8'd4;
14:help_char=8'd68;
15:help_char=8'd69;
16:help_char=8'd0;
17:help_char=8'd21;
18:help_char=8'd15;
19:help_char=8'd35;
20:help_char=8'd3;
21:help_char=8'd42;
22:help_char=8'd119;
endcase
4:case(pos)
0:help_char=8'd12;
1:help_char=8'd126;
2:help_char=8'd127;
3:help_char=8'd48;
4:help_char=8'd125;
5:help_char=8'd64;
6:help_char=8'd39;
7:help_char=8'd40;
8:help_char=8'd0;
9:help_char=8'd21;
10:help_char=8'd15;
11:help_char=8'd35;
12:help_char=8'd4;
13:help_char=8'd68;
14:help_char=8'd69;
15:help_char=8'd0;
16:help_char=8'd21;
17:help_char=8'd15;
18:help_char=8'd35;
19:help_char=8'd3;
20:help_char=8'd42;
21:help_char=8'd119;
endcase
endcase end endfunction
function [7:0] error_char;input [4:0] id;input [5:0] pos;begin error_char=0;case(id)
1:case(pos)
0:error_char=8'd58;
1:error_char=8'd59;
2:error_char=8'd68;
3:error_char=8'd87;
4:error_char=8'd60;
endcase
2:case(pos)
0:error_char=8'd61;
1:error_char=8'd62;
2:error_char=8'd88;
3:error_char=8'd89;
4:error_char=8'd90;
5:error_char=8'd91;
endcase
3:case(pos)
0:error_char=8'd92;
1:error_char=8'd93;
2:error_char=8'd94;
3:error_char=8'd95;
4:error_char=8'd96;
endcase
4:case(pos)
0:error_char=8'd97;
1:error_char=8'd48;
2:error_char=8'd98;
3:error_char=8'd68;
4:error_char=8'd69;
5:error_char=8'd90;
6:error_char=8'd91;
endcase
5:case(pos)
0:error_char=8'd99;
1:error_char=8'd100;
2:error_char=8'd53;
3:error_char=8'd101;
endcase
6:case(pos)
0:error_char=8'd66;
1:error_char=8'd67;
2:error_char=8'd90;
3:error_char=8'd102;
4:error_char=8'd103;
endcase
7:case(pos)
0:error_char=8'd104;
1:error_char=8'd105;
2:error_char=8'd51;
3:error_char=8'd106;
4:error_char=8'd90;
5:error_char=8'd91;
endcase
8:case(pos)
0:error_char=8'd68;
1:error_char=8'd69;
2:error_char=8'd107;
3:error_char=8'd108;
4:error_char=8'd109;
5:error_char=8'd110;
6:error_char=8'd111;
endcase
9:case(pos)
0:error_char=8'd112;
1:error_char=8'd113;
2:error_char=8'd114;
3:error_char=8'd115;
endcase
10:case(pos)
0:error_char=8'd39;
1:error_char=8'd116;
2:error_char=8'd117;
3:error_char=8'd48;
4:error_char=8'd118;
5:error_char=8'd110;
6:error_char=8'd111;
endcase
endcase end endfunction
function [7:0] footer_character;input row;input [5:0] col;begin footer_character=0;
if(fm[567:565]!=0)begin if(!row)begin
case(col)
0:footer_character=8'd63;
1:footer_character=8'd64;
2:footer_character=8'd147;
3:footer_character=status_char(status_id,0);
4:footer_character=status_char(status_id,1);
5:footer_character=status_char(status_id,2);
6:footer_character=status_char(status_id,3);
7:footer_character=status_char(status_id,4);
8:footer_character=status_char(status_id,5);
9:footer_character=status_char(status_id,6);
10:footer_character=status_char(status_id,7);
11:footer_character=status_char(status_id,8);
12:footer_character=8'd0;
13:footer_character=8'd15;
14:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[563:560]>>4 & 4'hf)):8'd150;
15:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[563:560]>>0 & 4'hf)):8'd150;
16:footer_character=8'd0;
17:footer_character=8'd16;
18:footer_character=8'd147;
19:footer_character=(1'b1)?(8'd1+(fimage>>28 & 4'hf)):8'd150;
20:footer_character=(1'b1)?(8'd1+(fimage>>24 & 4'hf)):8'd150;
21:footer_character=(1'b1)?(8'd1+(fimage>>20 & 4'hf)):8'd150;
22:footer_character=(1'b1)?(8'd1+(fimage>>16 & 4'hf)):8'd150;
23:footer_character=(1'b1)?(8'd1+(fimage>>12 & 4'hf)):8'd150;
24:footer_character=(1'b1)?(8'd1+(fimage>>8 & 4'hf)):8'd150;
25:footer_character=(1'b1)?(8'd1+(fimage>>4 & 4'hf)):8'd150;
26:footer_character=(1'b1)?(8'd1+(fimage>>0 & 4'hf)):8'd150;
27:footer_character=8'd0;
28:footer_character=8'd32;
29:footer_character=8'd147;
30:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[559:544]>>12 & 4'hf)):8'd150;
31:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[559:544]>>8 & 4'hf)):8'd150;
32:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[559:544]>>4 & 4'hf)):8'd150;
33:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[559:544]>>0 & 4'hf)):8'd150;
endcase
end else begin
if(fm[563:560]!=0)begin
case(fm[563:560])
0:begin
case(col)
0:footer_character=8'd0;
1:footer_character=8'd21;
2:footer_character=8'd15;
3:footer_character=8'd35;
4:footer_character=8'd4;
5:footer_character=8'd53;
6:footer_character=8'd68;
7:footer_character=8'd0;
8:footer_character=8'd21;
9:footer_character=8'd15;
10:footer_character=8'd35;
11:footer_character=8'd3;
12:footer_character=8'd42;
13:footer_character=8'd119;
endcase
end
1:begin
case(col)
0:footer_character=8'd58;
1:footer_character=8'd59;
2:footer_character=8'd68;
3:footer_character=8'd87;
4:footer_character=8'd60;
5:footer_character=8'd0;
6:footer_character=8'd21;
7:footer_character=8'd15;
8:footer_character=8'd35;
9:footer_character=8'd4;
10:footer_character=8'd53;
11:footer_character=8'd68;
12:footer_character=8'd0;
13:footer_character=8'd21;
14:footer_character=8'd15;
15:footer_character=8'd35;
16:footer_character=8'd3;
17:footer_character=8'd42;
18:footer_character=8'd119;
endcase
end
2:begin
case(col)
0:footer_character=8'd61;
1:footer_character=8'd62;
2:footer_character=8'd88;
3:footer_character=8'd89;
4:footer_character=8'd90;
5:footer_character=8'd91;
6:footer_character=8'd0;
7:footer_character=8'd21;
8:footer_character=8'd15;
9:footer_character=8'd35;
10:footer_character=8'd4;
11:footer_character=8'd53;
12:footer_character=8'd68;
13:footer_character=8'd0;
14:footer_character=8'd21;
15:footer_character=8'd15;
16:footer_character=8'd35;
17:footer_character=8'd3;
18:footer_character=8'd42;
19:footer_character=8'd119;
endcase
end
3:begin
case(col)
0:footer_character=8'd92;
1:footer_character=8'd93;
2:footer_character=8'd94;
3:footer_character=8'd95;
4:footer_character=8'd96;
5:footer_character=8'd0;
6:footer_character=8'd21;
7:footer_character=8'd15;
8:footer_character=8'd35;
9:footer_character=8'd4;
10:footer_character=8'd53;
11:footer_character=8'd68;
12:footer_character=8'd0;
13:footer_character=8'd21;
14:footer_character=8'd15;
15:footer_character=8'd35;
16:footer_character=8'd3;
17:footer_character=8'd42;
18:footer_character=8'd119;
endcase
end
4:begin
case(col)
0:footer_character=8'd97;
1:footer_character=8'd48;
2:footer_character=8'd98;
3:footer_character=8'd68;
4:footer_character=8'd69;
5:footer_character=8'd90;
6:footer_character=8'd91;
7:footer_character=8'd0;
8:footer_character=8'd21;
9:footer_character=8'd15;
10:footer_character=8'd35;
11:footer_character=8'd4;
12:footer_character=8'd53;
13:footer_character=8'd68;
14:footer_character=8'd0;
15:footer_character=8'd21;
16:footer_character=8'd15;
17:footer_character=8'd35;
18:footer_character=8'd3;
19:footer_character=8'd42;
20:footer_character=8'd119;
endcase
end
5:begin
case(col)
0:footer_character=8'd99;
1:footer_character=8'd100;
2:footer_character=8'd53;
3:footer_character=8'd101;
4:footer_character=8'd0;
5:footer_character=8'd21;
6:footer_character=8'd15;
7:footer_character=8'd35;
8:footer_character=8'd4;
9:footer_character=8'd53;
10:footer_character=8'd68;
11:footer_character=8'd0;
12:footer_character=8'd21;
13:footer_character=8'd15;
14:footer_character=8'd35;
15:footer_character=8'd3;
16:footer_character=8'd42;
17:footer_character=8'd119;
endcase
end
6:begin
case(col)
0:footer_character=8'd66;
1:footer_character=8'd67;
2:footer_character=8'd90;
3:footer_character=8'd102;
4:footer_character=8'd103;
5:footer_character=8'd0;
6:footer_character=8'd21;
7:footer_character=8'd15;
8:footer_character=8'd35;
9:footer_character=8'd4;
10:footer_character=8'd53;
11:footer_character=8'd68;
12:footer_character=8'd0;
13:footer_character=8'd21;
14:footer_character=8'd15;
15:footer_character=8'd35;
16:footer_character=8'd3;
17:footer_character=8'd42;
18:footer_character=8'd119;
endcase
end
7:begin
case(col)
0:footer_character=8'd104;
1:footer_character=8'd105;
2:footer_character=8'd51;
3:footer_character=8'd106;
4:footer_character=8'd90;
5:footer_character=8'd91;
6:footer_character=8'd0;
7:footer_character=8'd21;
8:footer_character=8'd15;
9:footer_character=8'd35;
10:footer_character=8'd4;
11:footer_character=8'd53;
12:footer_character=8'd68;
13:footer_character=8'd0;
14:footer_character=8'd21;
15:footer_character=8'd15;
16:footer_character=8'd35;
17:footer_character=8'd3;
18:footer_character=8'd42;
19:footer_character=8'd119;
endcase
end
8:begin
case(col)
0:footer_character=8'd68;
1:footer_character=8'd69;
2:footer_character=8'd107;
3:footer_character=8'd108;
4:footer_character=8'd109;
5:footer_character=8'd110;
6:footer_character=8'd111;
7:footer_character=8'd0;
8:footer_character=8'd21;
9:footer_character=8'd15;
10:footer_character=8'd35;
11:footer_character=8'd4;
12:footer_character=8'd53;
13:footer_character=8'd68;
14:footer_character=8'd0;
15:footer_character=8'd21;
16:footer_character=8'd15;
17:footer_character=8'd35;
18:footer_character=8'd3;
19:footer_character=8'd42;
20:footer_character=8'd119;
endcase
end
9:begin
case(col)
0:footer_character=8'd112;
1:footer_character=8'd113;
2:footer_character=8'd114;
3:footer_character=8'd115;
4:footer_character=8'd0;
5:footer_character=8'd21;
6:footer_character=8'd15;
7:footer_character=8'd35;
8:footer_character=8'd4;
9:footer_character=8'd53;
10:footer_character=8'd68;
11:footer_character=8'd0;
12:footer_character=8'd21;
13:footer_character=8'd15;
14:footer_character=8'd35;
15:footer_character=8'd3;
16:footer_character=8'd42;
17:footer_character=8'd119;
endcase
end
10:begin
case(col)
0:footer_character=8'd39;
1:footer_character=8'd116;
2:footer_character=8'd117;
3:footer_character=8'd48;
4:footer_character=8'd118;
5:footer_character=8'd110;
6:footer_character=8'd111;
7:footer_character=8'd0;
8:footer_character=8'd21;
9:footer_character=8'd15;
10:footer_character=8'd35;
11:footer_character=8'd4;
12:footer_character=8'd53;
13:footer_character=8'd68;
14:footer_character=8'd0;
15:footer_character=8'd21;
16:footer_character=8'd15;
17:footer_character=8'd35;
18:footer_character=8'd3;
19:footer_character=8'd42;
20:footer_character=8'd119;
endcase
end
endcase
end else if(fm[564])begin
case(col)
0:footer_character=8'd9;
1:footer_character=8'd60;
2:footer_character=8'd68;
3:footer_character=8'd69;
4:footer_character=8'd98;
5:footer_character=8'd139;
6:footer_character=8'd140;
7:footer_character=8'd141;
8:footer_character=8'd142;
9:footer_character=8'd0;
10:footer_character=8'd73;
11:footer_character=8'd51;
12:footer_character=8'd52;
13:footer_character=8'd143;
14:footer_character=8'd144;
15:footer_character=8'd0;
16:footer_character=8'd21;
17:footer_character=8'd15;
18:footer_character=8'd35;
19:footer_character=8'd3;
20:footer_character=8'd42;
21:footer_character=8'd119;
endcase
end else footer_character=help_char({2'd0,fm[567:565]},col);
end end
else case(fdiag)
0:begin if(!row)begin
case(col)
0:footer_character=mode_char(fmode,0);
1:footer_character=mode_char(fmode,1);
2:footer_character=mode_char(fmode,2);
3:footer_character=mode_char(fmode,3);
4:footer_character=8'd0;
5:footer_character=fzoom==0?8'd2:fzoom==1?8'd3:8'd5;
6:footer_character=8'd34;
7:footer_character=8'd0;
8:footer_character=fpair?8'd137:8'd135;
9:footer_character=fpair?8'd138:8'd136;
10:footer_character=8'd0;
11:footer_character=frotate?8'd2:8'd1;
12:footer_character=frotate?8'd9:8'd1;
13:footer_character=frotate?8'd1:8'd1;
14:footer_character=8'd0;
15:footer_character=8'd145;
16:footer_character=8'd146;
17:footer_character=8'd147;
18:footer_character=status_char(status_id,0);
19:footer_character=status_char(status_id,1);
20:footer_character=status_char(status_id,2);
21:footer_character=status_char(status_id,3);
22:footer_character=status_char(status_id,4);
23:footer_character=status_char(status_id,5);
24:footer_character=status_char(status_id,6);
25:footer_character=status_char(status_id,7);
26:footer_character=8'd0;
27:footer_character=8'd28;
28:footer_character=8'd17;
29:footer_character=8'd12;
30:footer_character=8'd147;
31:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[18][8+:4]):8'd150;
32:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[18][4+:4]):8'd150;
33:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[18][0+:4]):8'd150;
34:footer_character=8'd148;
35:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[19][8+:4]):8'd150;
36:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[19][4+:4]):8'd150;
37:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[19][0+:4]):8'd150;
38:footer_character=8'd148;
39:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[20][8+:4]):8'd150;
40:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[20][4+:4]):8'd150;
41:footer_character=(fsample && fmode==1 && fshow)?(8'd1+numbers[20][0+:4]):8'd150;
endcase
end else begin
case(col)
0:footer_character=8'd16;
1:footer_character=8'd147;
2:footer_character=(1'b1)?(8'd1+(fimage>>28 & 4'hf)):8'd150;
3:footer_character=(1'b1)?(8'd1+(fimage>>24 & 4'hf)):8'd150;
4:footer_character=(1'b1)?(8'd1+(fimage>>20 & 4'hf)):8'd150;
5:footer_character=(1'b1)?(8'd1+(fimage>>16 & 4'hf)):8'd150;
6:footer_character=(1'b1)?(8'd1+(fimage>>12 & 4'hf)):8'd150;
7:footer_character=(1'b1)?(8'd1+(fimage>>8 & 4'hf)):8'd150;
8:footer_character=(1'b1)?(8'd1+(fimage>>4 & 4'hf)):8'd150;
9:footer_character=(1'b1)?(8'd1+(fimage>>0 & 4'hf)):8'd150;
10:footer_character=8'd0;
11:footer_character=8'd32;
12:footer_character=8'd147;
13:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[559:544]>>12 & 4'hf)):8'd150;
14:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[559:544]>>8 & 4'hf)):8'd150;
15:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[559:544]>>4 & 4'hf)):8'd150;
16:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[559:544]>>0 & 4'hf)):8'd150;
17:footer_character=8'd0;
18:footer_character=8'd11;
19:footer_character=8'd147;
20:footer_character=(fdetection && fm[245])?(8'd1+numbers[0][20+:4]):8'd150;
21:footer_character=(fdetection && fm[245])?(8'd1+numbers[0][16+:4]):8'd150;
22:footer_character=(fdetection && fm[245])?(8'd1+numbers[0][12+:4]):8'd150;
23:footer_character=(fdetection && fm[245])?(8'd1+numbers[0][8+:4]):8'd150;
24:footer_character=(fdetection && fm[245])?(8'd1+numbers[0][4+:4]):8'd150;
25:footer_character=(fdetection && fm[245])?(8'd1+numbers[0][0+:4]):8'd150;
26:footer_character=8'd148;
27:footer_character=(fdetection && fm[245])?(8'd1+numbers[6][8+:4]):8'd150;
28:footer_character=(fdetection && fm[245])?(8'd1+numbers[6][4+:4]):8'd150;
29:footer_character=(fdetection && fm[245])?(8'd1+numbers[6][0+:4]):8'd150;
30:footer_character=8'd0;
31:footer_character=8'd12;
32:footer_character=8'd147;
33:footer_character=(fdetection && fm[246])?(8'd1+numbers[1][20+:4]):8'd150;
34:footer_character=(fdetection && fm[246])?(8'd1+numbers[1][16+:4]):8'd150;
35:footer_character=(fdetection && fm[246])?(8'd1+numbers[1][12+:4]):8'd150;
36:footer_character=(fdetection && fm[246])?(8'd1+numbers[1][8+:4]):8'd150;
37:footer_character=(fdetection && fm[246])?(8'd1+numbers[1][4+:4]):8'd150;
38:footer_character=(fdetection && fm[246])?(8'd1+numbers[1][0+:4]):8'd150;
39:footer_character=8'd148;
40:footer_character=(fdetection && fm[246])?(8'd1+numbers[7][8+:4]):8'd150;
41:footer_character=(fdetection && fm[246])?(8'd1+numbers[7][4+:4]):8'd150;
42:footer_character=(fdetection && fm[246])?(8'd1+numbers[7][0+:4]):8'd150;
endcase
end end
1:begin if(!row)begin
case(col)
0:footer_character=8'd11;
1:footer_character=(fm[604])?(8'd1+numbers[2][20+:4]):8'd150;
2:footer_character=(fm[604])?(8'd1+numbers[2][16+:4]):8'd150;
3:footer_character=(fm[604])?(8'd1+numbers[2][12+:4]):8'd150;
4:footer_character=(fm[604])?(8'd1+numbers[2][8+:4]):8'd150;
5:footer_character=(fm[604])?(8'd1+numbers[2][4+:4]):8'd150;
6:footer_character=(fm[604])?(8'd1+numbers[2][0+:4]):8'd150;
7:footer_character=8'd152;
8:footer_character=(fm[604])?(8'd1+numbers[3][20+:4]):8'd150;
9:footer_character=(fm[604])?(8'd1+numbers[3][16+:4]):8'd150;
10:footer_character=(fm[604])?(8'd1+numbers[3][12+:4]):8'd150;
11:footer_character=(fm[604])?(8'd1+numbers[3][8+:4]):8'd150;
12:footer_character=(fm[604])?(8'd1+numbers[3][4+:4]):8'd150;
13:footer_character=(fm[604])?(8'd1+numbers[3][0+:4]):8'd150;
14:footer_character=8'd0;
15:footer_character=8'd24;
16:footer_character=(fm[604])?(8'd1+fm[338:336]):8'd150;
17:footer_character=8'd0;
18:footer_character=8'd27;
19:footer_character=(fdetection && fm[245])?(8'd1+numbers[6][8+:4]):8'd150;
20:footer_character=(fdetection && fm[245])?(8'd1+numbers[6][4+:4]):8'd150;
21:footer_character=(fdetection && fm[245])?(8'd1+numbers[6][0+:4]):8'd150;
22:footer_character=8'd0;
23:footer_character=8'd29;
24:footer_character=(fdetection && fm[245])?(8'd1+fm[365:364]):8'd150;
25:footer_character=8'd0;
26:footer_character=8'd16;
27:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[345:342]>>0 & 4'hf)):8'd150;
endcase
end else begin
case(col)
0:footer_character=8'd12;
1:footer_character=(fm[604])?(8'd1+numbers[4][20+:4]):8'd150;
2:footer_character=(fm[604])?(8'd1+numbers[4][16+:4]):8'd150;
3:footer_character=(fm[604])?(8'd1+numbers[4][12+:4]):8'd150;
4:footer_character=(fm[604])?(8'd1+numbers[4][8+:4]):8'd150;
5:footer_character=(fm[604])?(8'd1+numbers[4][4+:4]):8'd150;
6:footer_character=(fm[604])?(8'd1+numbers[4][0+:4]):8'd150;
7:footer_character=8'd152;
8:footer_character=(fm[604])?(8'd1+numbers[5][20+:4]):8'd150;
9:footer_character=(fm[604])?(8'd1+numbers[5][16+:4]):8'd150;
10:footer_character=(fm[604])?(8'd1+numbers[5][12+:4]):8'd150;
11:footer_character=(fm[604])?(8'd1+numbers[5][8+:4]):8'd150;
12:footer_character=(fm[604])?(8'd1+numbers[5][4+:4]):8'd150;
13:footer_character=(fm[604])?(8'd1+numbers[5][0+:4]):8'd150;
14:footer_character=8'd0;
15:footer_character=8'd24;
16:footer_character=(fm[604])?(8'd1+fm[341:339]):8'd150;
17:footer_character=8'd0;
18:footer_character=8'd27;
19:footer_character=(fdetection && fm[246])?(8'd1+numbers[7][8+:4]):8'd150;
20:footer_character=(fdetection && fm[246])?(8'd1+numbers[7][4+:4]):8'd150;
21:footer_character=(fdetection && fm[246])?(8'd1+numbers[7][0+:4]):8'd150;
22:footer_character=8'd0;
23:footer_character=8'd29;
24:footer_character=(fdetection && fm[246])?(8'd1+fm[367:366]):8'd150;
25:footer_character=8'd0;
26:footer_character=8'd16;
27:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[349:346]>>0 & 4'hf)):8'd150;
28:footer_character=8'd0;
29:footer_character=8'd26;
30:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+fm[369:368]):8'd150;
31:footer_character=8'd0;
32:footer_character=8'd28;
33:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[377:370]>>4 & 4'hf)):8'd150;
34:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+(fm[377:370]>>0 & 4'hf)):8'd150;
35:footer_character=8'd0;
36:footer_character=8'd13;
37:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+fm[379:378]):8'd150;
38:footer_character=8'd0;
39:footer_character=8'd22;
40:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[21][4+:4]):8'd150;
41:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[21][0+:4]):8'd150;
endcase
end end
2:begin if(!row)begin
case(col)
0:footer_character=8'd11;
1:footer_character=8'd0;
2:footer_character=8'd18;
3:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[8][8+:4]):8'd150;
4:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[8][4+:4]):8'd150;
5:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[8][0+:4]):8'd150;
6:footer_character=8'd148;
7:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[9][8+:4]):8'd150;
8:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[9][4+:4]):8'd150;
9:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[9][0+:4]):8'd150;
10:footer_character=8'd0;
11:footer_character=8'd23;
12:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[10][8+:4]):8'd150;
13:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[10][4+:4]):8'd150;
14:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[10][0+:4]):8'd150;
15:footer_character=8'd0;
16:footer_character=8'd14;
17:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[11][8+:4]):8'd150;
18:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[11][4+:4]):8'd150;
19:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[11][0+:4]):8'd150;
20:footer_character=8'd0;
21:footer_character=8'd29;
22:footer_character=fm[444:443]==0?8'd4:fm[444:443]==1?8'd5:fm[444:443]==2?8'd7:8'd9;
23:footer_character=8'd148;
24:footer_character=8'd2;
25:footer_character=8'd7;
26:footer_character=8'd0;
27:footer_character=8'd28;
28:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[16][12+:4]):8'd150;
29:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[16][8+:4]):8'd150;
30:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[16][4+:4]):8'd150;
31:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[16][0+:4]):8'd150;
32:footer_character=8'd0;
33:footer_character=8'd12;
34:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[17][12+:4]):8'd150;
35:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[17][8+:4]):8'd150;
36:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[17][4+:4]):8'd150;
37:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[17][0+:4]):8'd150;
endcase
end else begin
case(col)
0:footer_character=8'd12;
1:footer_character=8'd0;
2:footer_character=8'd18;
3:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[12][8+:4]):8'd150;
4:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[12][4+:4]):8'd150;
5:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[12][0+:4]):8'd150;
6:footer_character=8'd148;
7:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[13][8+:4]):8'd150;
8:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[13][4+:4]):8'd150;
9:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[13][0+:4]):8'd150;
10:footer_character=8'd0;
11:footer_character=8'd23;
12:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[14][8+:4]):8'd150;
13:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[14][4+:4]):8'd150;
14:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[14][0+:4]):8'd150;
15:footer_character=8'd0;
16:footer_character=8'd14;
17:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[15][8+:4]):8'd150;
18:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[15][4+:4]):8'd150;
19:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[15][0+:4]):8'd150;
20:footer_character=8'd0;
21:footer_character=8'd29;
22:footer_character=fm[508:507]==0?8'd4:fm[508:507]==1?8'd5:fm[508:507]==2?8'd7:8'd9;
23:footer_character=8'd148;
24:footer_character=8'd2;
25:footer_character=8'd7;
26:footer_character=8'd0;
27:footer_character=8'd30;
28:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[22][20+:4]):8'd150;
29:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[22][16+:4]):8'd150;
30:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[22][12+:4]):8'd150;
31:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[22][8+:4]):8'd150;
32:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[22][4+:4]):8'd150;
33:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[22][0+:4]):8'd150;
34:footer_character=8'd0;
35:footer_character=8'd36;
36:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[23][16+:4]):8'd150;
37:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[23][12+:4]):8'd150;
38:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[23][8+:4]):8'd150;
39:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[23][4+:4]):8'd150;
40:footer_character=(fm[255] && fm[415:413]==3)?(8'd1+numbers[23][0+:4]):8'd150;
endcase
end end
endcase end endfunction

 always @(posedge I_clk or negedge I_rst_n)begin
 if(!I_rst_n)begin
 fm<=0;fimage<=0;fmode<=0;fzoom<=0;fdiag<=0;fstate<=6;fpair<=0;frotate<=1;ftracking<=0;fshow<=1;fvideo<=0;fdetection<=0;fsample<=0;
 format_state<=0;field_index<=0;bit_index<=0;binary<=0;decimal<=0;format_col<=0;format_row<=0;footer_ready<=0;
 end else begin
 case(format_state)
 1:begin binary<=field_value(field_index);decimal<=0;bit_index<=0;format_state<=2;end
 2:begin binary<=binary<<1;decimal<={adjusted[22:0],binary[19]};
 if(bit_index==19)begin numbers[field_index]<={adjusted[22:0],binary[19]};
 if(field_index==23)begin format_col<=0;format_row<=0;format_state<=3;end
 else begin field_index<=field_index+1'b1;format_state<=1;end end
 else bit_index<=bit_index+1'b1;end
 3:begin characters[(format_row?COLS:0)+format_col]<=footer_character(format_row,format_col);
 if(format_col==COLS-1)begin format_col<=0;if(format_row)begin footer_ready<=1;format_state<=0;end else format_row<=1;end
 else format_col<=format_col+1'b1;end
 endcase
 if(I_de && y==620 && x==0)begin
 fm<=I_meta;fimage<=I_image_id;fmode<=I_mode;fzoom<=I_zoom;fdiag<=I_diag;fstate<=I_state;
 fpair<=I_pair;frotate<=I_rotate;ftracking<=I_tracking;fshow<=I_show;fvideo<=I_video_ok;fdetection<=I_detection_valid;fsample<=I_sample_valid;
 field_index<=0;footer_ready<=0;format_state<=1;
 end end end
 function signed [13:0] mapx;input [10:0] v;reg signed [13:0] d;begin
 d=$signed({3'd0,v})-$signed({3'd0,I_x0});
 mapx=(I_rotate?($signed(14'd1280>>>I_zoom)-1-d):d)<<<I_zoom;end endfunction
 function signed [13:0] mapy;input [9:0] v;reg signed [13:0] d;begin
 d=$signed({4'd0,v})-$signed({4'd0,I_y0});
 mapy=(I_rotate?($signed(14'd624>>>I_zoom)-1-d):d)<<<I_zoom;end endfunction
 function border;input signed [13:0] xx,yy,x0,x1,y0,y1;reg signed [13:0] l,r,t,b;begin
 l=xx-x0;r=x1-xx;t=yy-y0;b=y1-yy;
 border=!(l[13] || r[13] || t[13] || b[13]) && (l[13:1]==0 || r[13:1]==0 || t[13:1]==0 || b[13:1]==0);end endfunction
 wire [23:0] color_a=I_pair?24'hffff40:24'hff6060,color_b=I_pair?24'he080ff:24'h6090ff;
 reg [5:0] footer_col;reg [4:0] footer_px;
 reg [7:0] footer_glyph;reg [4:0] footer_gy;reg footer_text,footer_row;
 reg [3:0] label_glyph,label_gx,label_gy;reg label_text,back_on,logo_on;
 reg [23:0] ink,back;reg [12:0] logo_addr;reg [41:0] box;reg valid_box;
 reg signed [13:0] xx,yy,bx0,bx1,by0,by1,lx,ly,ldx,ldy;
 integer j,lc;reg [9:0] logo_y;reg [10:0] logo_x;
 localparam [31:0] WAIT_WORD={8'd84,8'd37,8'd85,8'd86};
 wire footer_current=footer_ready && I_tracking==ftracking && I_video_ok==fvideo && I_detection_valid==fdetection && I_state==fstate;
 always @*begin
 footer_glyph=0;footer_gy=0;footer_text=0;footer_row=0;label_glyph=0;label_gx=0;label_gy=0;label_text=0;
 back_on=0;back=24'h101824;ink=24'hf0f4ff;logo_on=0;logo_addr=0;logo_y=0;logo_x=0;
 box=0;valid_box=0;xx=$signed({3'd0,x});yy=$signed({4'd0,y});bx0=0;bx1=0;by0=0;by1=0;lx=0;ly=0;ldx=0;ldy=0;lc=0;
 if(y>=624)begin
 back_on=1;
 if(x>=1152)back=24'hffffff;
 if(x>=1168 && x<1264 && y>=641 && y<703)begin
 logo_on=1;logo_y=y-641;logo_x=x-1168;logo_addr=(logo_y<<6)+(logo_y<<5)+logo_x;end
 if(x>=16 && x<16+COLS*FONT && ((y>=632+(32-FONT)/2 && y<632+(32-FONT)/2+FONT) ||
 (y>=676+(32-FONT)/2 && y<676+(32-FONT)/2+FONT)))begin
 footer_row=y>=676;footer_gy=footer_row?y-(676+(32-FONT)/2):y-(632+(32-FONT)/2);
 footer_text=1;
 if(footer_current)footer_glyph=characters[(footer_row?COLS:0)+footer_col];
 else if(footer_ready && !footer_row && footer_col<4)footer_glyph=WAIT_WORD>>((3-footer_col)*8);
 end
 end else if(I_video_ok)begin
 if(I_show && I_detection_valid)for(j=0;j<2;j=j+1)begin
 box=j==0?I_meta[141:100]:I_meta[183:142];valid_box=j==0?I_meta[245]:I_meta[246];
 bx0=mapx(I_rotate?box[21:11]:box[10:0]);bx1=mapx(I_rotate?box[10:0]:box[21:11])+(14'sd1<<<I_zoom)-1;
 by0=mapy(I_rotate?box[41:32]:box[31:22]);by1=mapy(I_rotate?box[31:22]:box[41:32])+(14'sd1<<<I_zoom)-1;
 if(valid_box && bx1>=0 && bx0<1280 && by1>=0 && by0<624)begin
 if(border(xx,yy,bx0,bx1,by0,by1))begin back_on=1;back=j==0?color_a:color_b;end
 lx=bx0<0?0:bx0>1216?1216:bx0;ly=by0>=18?by0-18:by1+3;
 if(ly>608)ly=608;if(ly<0)ly=0;ldx=xx-lx;ldy=yy-ly;
 if(ldx[13:6]==0 && ldy[13:4]==0)begin
 back_on=1;back=24'h101824;label_text=1;ink=j==0?color_a:color_b;label_gx=ldx[3:0];label_gy=ldy[3:0];lc=ldx[5:4];
 case(lc)0:label_glyph=j==0?(I_pair?3:1):(I_pair?4:2);1:label_glyph=5;2:label_glyph=j==0?6:7;3:label_glyph=8;endcase
 end end end
 if(I_show && I_detection_valid && I_meta[32])begin
 lx=mapx(I_meta[89:79]);ly=mapy(I_meta[99:90]);ldx=xx-lx;ldy=yy-ly;
 if((ldx>=-6 && ldx<=6 && ldy>=-1 && ldy<=1)||(ldy>=-6 && ldy<=6 && ldx>=-1 && ldx<=1))begin back_on=1;back=24'h40ff90;end end
 if(I_meta[567:565]!=0 && I_meta[567:565]!=2 && border(xx,yy,mapx(I_rotate?647:632),mapx(I_rotate?632:647)+(14'sd1<<<I_zoom)-1,
 mapy(I_rotate?367:352),mapy(I_rotate?352:367)+(14'sd1<<<I_zoom)-1))begin back_on=1;back=24'h80ff80;end
 if(I_show && I_tracking && I_meta[36:33]<=2 && border(xx,yy,mapx(I_rotate?959:320),mapx(I_rotate?320:959),mapy(I_rotate?539:180),mapy(I_rotate?180:539)))begin back_on=1;back=24'h40c080;end
 if(I_show && I_mode==1 && border(xx,yy,mapx(I_rotate?643:636),mapx(I_rotate?636:643)+(14'sd1<<<I_zoom)-1,
 mapy(I_rotate?363:356),mapy(I_rotate?356:363)+(14'sd1<<<I_zoom)-1))begin back_on=1;back=24'h80ff80;end
 end end
 wire [11:0] footer_addr=(footer_glyph<<4)+(footer_glyph<<3)+footer_gy;
 wire [FONT-1:0] footer_font_row;wire [15:0] label_font_row;wire [1:0] logo_pixel;
 stable_footer_glyph_rom footer_font(I_clk,footer_addr,footer_font_row);
 stable_glyph_rom label_font(I_clk,{label_glyph,label_gy},label_font_row);
 scaling_logo_rom logo(I_clk,logo_addr,logo_pixel);
 reg [4:0] footer_px_d;reg [3:0] label_gx_d;reg footer_d,label_d,logo_d,back_d,vs_d,hs_d,de_d;
 reg [23:0] ink_d,bg_d,rgb_d;
 always @(posedge I_clk or negedge I_rst_n)begin
 if(!I_rst_n)begin
 x<=0;y<=0;vs_last<=0;footer_col<=0;footer_px<=0;footer_px_d<=0;label_gx_d<=0;footer_d<=0;label_d<=0;logo_d<=0;back_d<=0;
 vs_d<=0;hs_d<=0;de_d<=0;ink_d<=0;bg_d<=0;rgb_d<=0;O_vs<=0;O_hs<=0;O_de<=0;O_rgb<=0;
 end else begin
 vs_last<=I_vs;if(I_vs && !vs_last)begin x<=0;y<=0;end
 else if(I_de)begin if(x==1279)begin x<=0;y<=y+1'b1;end else x<=x+1'b1;end
 if(I_de)begin if(x==0)begin footer_col<=0;footer_px<=0;end
 else if(x>=16 && x<16+COLS*FONT)begin if(footer_px==FONT-1)begin footer_px<=0;footer_col<=footer_col+1'b1;end else footer_px<=footer_px+1'b1;end end
 footer_px_d<=footer_px;label_gx_d<=label_gx;footer_d<=footer_text;label_d<=label_text;logo_d<=logo_on;back_d<=back_on;
 ink_d<=ink;bg_d<=back;rgb_d<=I_rgb;vs_d<=I_vs;hs_d<=I_hs;de_d<=I_de;
 O_vs<=vs_d;O_hs<=hs_d;O_de<=de_d;
 O_rgb<=logo_d?(logo_pixel==1?24'h1c2c4e:logo_pixel==2?24'hed1b23:24'hffffff):
 footer_d && footer_font_row[FONT-1-footer_px_d]?ink_d:
 label_d && label_font_row[15-label_gx_d]?ink_d:back_d?bg_d:rgb_d;
 end end
endmodule
`default_nettype wire
