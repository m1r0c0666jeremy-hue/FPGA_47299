"""Audit the exact f395 candidate source + cf8 ingress combination."""
from pathlib import Path
import argparse, hashlib, json, re, subprocess

R=Path(__file__).resolve().parents[1]
P='target_lock_candidates_ingress'
BASE='f395cc011ef4c21f15863192ce148938834bd639'
FIX='cf8b7c463a415bd8741fed4ec68ff3eeac252455'
def sha(path): return hashlib.sha256((R/path).read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R)
parser=argparse.ArgumentParser()
parser.add_argument('--snapshot',action='store_true')
parser.add_argument('--sources-only',action='store_true')
args=parser.parse_args()
restore=json.loads((R/'reports/candidate_ingress_restore_manifest.json').read_text(encoding='utf-8'))
assert git('branch','--show-current').decode().strip()=='LockingnTracking'
assert git('rev-parse','HEAD').decode().strip()==FIX
fixed='user_source/hdl_source/video_in.v'
for path in restore['old_inputs']:
    expected=git('show',f'{FIX if path==fixed else BASE}:{path}')
    assert (R/path).read_bytes()==expected,f'Unexpected source change: {path}'
project=R/f'td_project/{P}.al'
paths=re.findall(r'<File Path="([^"]+)"',project.read_text(encoding='utf-8'))
historic=re.findall(r'<File Path="([^"]+)"',git('show',f'{BASE}:td_project/target_lock_candidates.al').decode())
assert paths==historic, 'Experimental build must use exactly the historic source list'
assert all((project.parent/path).is_file() for path in paths), 'Missing build source'
for path,checksum in restore['old_bits'].items(): assert sha(path)==checksum,f'Old bit changed: {path}'
generation=json.loads((R/'reports/target_generation_manifest.json').read_text(encoding='utf-8'))
for path,checksum in generation['files'].items(): assert sha(path)==checksum,f'Generated artifact mismatch: {path}'
test_sources={}
for path in [*(f'scripts/test_candidate_{stage}.py' for stage in ['unit','detection','full','video','osd','regression']),
             'scripts/candidate_reference.py','scripts/test_imagepreprocess_10_3.py',
             *(str(p.relative_to(R)).replace('\\','/') for p in (R/'sim').glob('tb_candidate_*.sv')),
             'sim/tb_scaling_video.sv','sim/tb_target_ingress_probe.sv','sim/fifo_model.sv']:
    assert (R/path).read_bytes()==git('show',f'{BASE}:{path}'),f'Historic test changed: {path}'
    test_sources[path]=sha(path)
for path in ['scripts/test_robust_ingress.py','sim/tb_robust_ingress.sv']:
    assert (R/path).read_bytes()==git('show',f'{FIX}:{path}'),f'Extracted ingress test changed: {path}'
    test_sources[path]=sha(path)
test_sources={}
for path in [*(f'scripts/test_candidate_{stage}.py' for stage in ['unit','detection','full','video','osd','regression']),
             'scripts/candidate_reference.py','scripts/test_imagepreprocess_10_3.py',
             *(str(p.relative_to(R)).replace('\\','/') for p in (R/'sim').glob('tb_candidate_*.sv')),
             'sim/tb_scaling_video.sv','sim/tb_target_ingress_probe.sv','sim/fifo_model.sv']:
    assert (R/path).read_bytes()==git('show',f'{BASE}:{path}'),f'Historic test changed: {path}'
    test_sources[path]=sha(path)
for path in ['scripts/test_robust_ingress.py','sim/tb_robust_ingress.sv']:
    assert (R/path).read_bytes()==git('show',f'{FIX}:{path}'),f'Extracted ingress test changed: {path}'
    test_sources[path]=sha(path)
inputs={path:sha(path) for path in restore['old_inputs']}
for path in [f'td_project/{P}.al',f'scripts/build_{P}.tcl']:
    inputs[path]=sha(path)
snapshot=R/'reports/candidate_ingress_build_inputs.json'
if args.snapshot:
    assert not snapshot.exists(),'Do not overwrite an earlier build snapshot'
    snapshot.write_text(json.dumps({'inputs':inputs,'baseline':BASE,'fix_source':FIX},indent=2)+'\n',encoding='utf-8')
    print('CANDIDATE_INGRESS_INPUTS_CAPTURED',len(inputs));raise SystemExit
assert json.loads(snapshot.read_text())['inputs']==inputs,'Build inputs changed after snapshot'
if args.sources_only:
    print('CANDIDATE_INGRESS_SOURCES_PASS',len(inputs),'inputs',len(restore['old_bits']),'preserved bits')
    raise SystemExit
requirements={
 'candidate_ingress_unit_simulation.log':['CANDIDATE_UNIT_TESTS_PASSED','PASS detector 1280x720 frames=2'],
 'candidate_ingress_detection_simulation.log':['PASS'],
 'candidate_ingress_full_simulation.log':['PASS detector 1280x720 frames=5'],
 'candidate_ingress_ingress.log':['PASS AWB 960 packed = 960 DDR','CP=11 DP=5'],
 'candidate_ingress_video_simulation.log':['PASS target video:'],
 'candidate_ingress_osd_simulation.log':['PASS'],
 'candidate_ingress_preprocess_regression.log':['exit 0'],
}
for name,terms in requirements.items():
    text=(R/'reports'/name).read_text(encoding='utf-8')
    assert all(term in text for term in terms),(name,terms)
    assert not any(term in text for term in ['FATAL:','Traceback','ERROR:']),name
video=(R/'reports/candidate_ingress_video_simulation.log').read_text()
assert video.count('PASS target video:')==15
assert sum(map(int,re.findall(r'pixels=\s*(\d+)',video)))==15175680
osd=(R/'reports/candidate_ingress_osd_simulation.log').read_text()
assert osd.count('PASS OSD')==72, f'OSD count changed: {osd.count("PASS OSD")}'
out=R/f'build/{P}'
timing=(out/f'{P}_phy.ts').read_text()
for kind in ('SWNS','HWNS'):
    assert float(re.search(kind+r':\s*(-?[\d.]+)ns',timing).group(1))>=0,kind
log=(R/'reports/candidate_ingress_build.log').read_text(encoding='utf-8',errors='replace')
assert 'TARGET_LOCK_CANDIDATES_INGRESS_BUILD_COMPLETED' in log and 'BUILD_FAILED' not in log
manifest={'status':'SOFTWARE_AND_TD_BUILD_PASSED_HARDWARE_PENDING',
 'baseline':BASE,'fix_source':FIX,'branch':'LockingnTracking','head_unchanged':FIX,
 'inputs':inputs,'old_bits':restore['old_bits'],'workspace_backup':restore['workspace_backup'],
 'historic_test_sources':test_sources,
 'test_dispatcher_sha256':sha('scripts/test_candidates_ingress.py'),
 'historic_test_sources':test_sources,
 'test_dispatcher_sha256':sha('scripts/test_candidates_ingress.py'),
 'bit':f'build/{P}/{P}.bit','bit_sha256':sha(f'build/{P}/{P}.bit'),
 'hardware':'New combination not tested on board; prior cf8 ingress fix reported successful by Jeremy',
 'evidence':{str(path.relative_to(R)).replace('\\','/'):sha(path.relative_to(R)) for path in [
     *(R/'reports'/name for name in requirements),R/'reports/candidate_ingress_build.log',
     *out.glob('*.area'),*out.glob('*.ts'),*out.glob('*.timing')]}}
(R/'reports/candidate_ingress_build_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('CANDIDATE_INGRESS_AUDIT_PASS',manifest['bit_sha256'],'inputs',len(inputs),'old bits',len(restore['old_bits']))
