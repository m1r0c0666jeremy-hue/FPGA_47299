"""Private explicit-ERAM footer prototype; preserves the production inputs."""
from pathlib import Path
import argparse,sys,xml.etree.ElementTree as ET
from refined_testlib import R
from refined_digits_ram import transform

ap=argparse.ArgumentParser();ap.add_argument('--synth',action='store_true');a=ap.parse_args()
out=R/'build/refined_digit_eram_async_prototype';out.mkdir(exist_ok=True)
s=transform((R/'rtl/color_regions/refined_osd.v').read_text(encoding='utf-8'))
s=s.replace('(* ram_style="bram" *) reg [3:0] digits[0:255];','')
s=s.replace('reg [2:0] digit_index;reg [3:0] digit_q;','reg [2:0] digit_index;wire [3:0] digit_q;')
old=''' always @(posedge I_clk)begin
 digit_q<=digits[{token_data[12:8],token_data[2:0]}];
 if(format_state==8)digits[{field_index,digit_index}]<=bcd_word[3:0];
 end'''
assert old in s
s=s.replace(old,''' refined_digit_eram digit_store(I_clk,format_state==8,
 {field_index,digit_index},bcd_word[3:0],{token_data[12:8],token_data[2:0]},digit_q);''')
s+='''
// The Icarus branch models a single synchronous read and write port. It does
// not model vendor physical timing or same-address read/write collisions.
module refined_digit_eram(input wire clk,we,input wire [7:0] wa,
 input wire [3:0] data,input wire [7:0] ra,output wire [3:0] q);
`ifdef __ICARUS__
 reg [3:0] mem[0:255];reg [3:0] read_q;
 always @(posedge clk)begin if(we)mem[wa]<=data;read_q<=mem[ra];end
 assign q=read_q;
`else
 wire [19:0] read_q;
 PH1P_LOGIC_ERAM #(.DATA_WIDTH_A(20),.DATA_WIDTH_B(20),
 .ADDR_WIDTH_A(10),.ADDR_WIDTH_B(10),.DATA_DEPTH_A(1024),.DATA_DEPTH_B(1024),
 .MODE("DP"),.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
 .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.IMPLEMENT("20K(FAST)"),
 .ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),.CLKMODE("SYNC"),
 .SSROVERCE("DISABLE"),.OREGSET_A("RESET"),.OREGSET_B("RESET"),
 .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),
 .ASYNC_RESET_RELEASE_A("SYNC"),.ASYNC_RESET_RELEASE_B("SYNC"),
 .INIT_FILE("NONE"),.FILL_ALL("NONE")) storage(
 .dia({16'd0,data}),.addra({2'd0,wa}),.cea(1'b1),.ocea(1'b0),.clka(clk),.wea(we),.rsta(1'b0),.bea(1'b0),
 .dib(20'd0),.addrb({2'd0,ra}),.ceb(1'b1),.oceb(1'b0),.clkb(clk),.web(1'b0),.rstb(1'b0),.beb(1'b0),
 .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0),.doa(),.dob(read_q),.ecc_sbiterr(),.ecc_dbiterr());
 assign q=read_q[3:0];
`endif
endmodule
'''
candidate=out/'refined_osd.v';data=s.encode('utf-8')
if candidate.exists():assert candidate.read_bytes()==data
else:candidate.write_bytes(data)
if not a.synth:
 path=R/'scripts/test_refined_v4_ui.py';s=path.read_text(encoding='utf-8')
 s=s.replace("run('refined_v4_ui_pixels'","run('digits_explicit_eram_async_ui_pixels'")
 s=s.replace("[R/'rtl/color_regions'/f'{n}.v' for n in", "[candidate if n=='refined_osd' else R/'rtl/color_regions'/f'{n}.v' for n in")
 exec(compile(s,str(path),'exec'),dict(__file__=str(path),__name__='__main__',candidate=candidate))
else:
 original=R/'td_project/target_color_regions_refined.al'
 tree=ET.fromstring(original.read_text(encoding='utf-8').replace('&','&amp;').replace('::','__TD_COLON__'))
 for node in tree.findall('./Source_Files/*/File'):
  p=(original.parent/node.attrib['Path']).resolve();node.set('Path',(candidate if p.name=='refined_osd.v' else p).as_posix())
 project=out/'prototype.al';project.write_bytes(('<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(tree,encoding='unicode').replace('&amp;','&').replace('__TD_COLON__','::')+'\n').encode('utf-8'))
 path=R/'scripts/run_refined_build.py';s=path.read_text(encoding='utf-8')
 s=s.replace("project=R/'td_project/target_color_regions_refined.al'","project=prototype_project")
 s=s.replace("f'refined_{a.stage}_{stamp}'","f'refined_digit_eram_async_{a.stage}_{stamp}'")
 sys.argv=[str(path),'--stage','synth']
 exec(compile(s,str(path),'exec'),dict(__file__=str(path),__name__='__main__',prototype_project=project))
