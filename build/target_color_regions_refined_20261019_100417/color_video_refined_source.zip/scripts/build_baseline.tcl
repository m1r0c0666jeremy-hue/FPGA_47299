# Run from any directory with td_commands_prompt.exe <this-file>.
set root [file normalize [file join [file dirname [info script]] ..]]
set project [file join $root vendor_reference lab1 td_project camera_to_dsi_display.al]
set out [file join $root build baseline]
file mkdir $out
cd $out
if {[catch {
    import_device ph1_35p.db -package PH1P35MDG324 -speed 3
    cd [file dirname $project]
    open_project $project -single_run
    elaborate -top design_top_wrapper
    cd $out
    read_adc [file join $root vendor_reference lab1 user_source constraints_source pin.adc]
    read_ip_adc -ip ddr2 -file [file join $root vendor_reference lab1 user_source hdl_source ph1p35_ddr ddr2 src adc ddr2.adc]
    read_sdc [file join $root vendor_reference lab1 td_project camera_to_dsi_display.sdc]
    read_sdc -ip ddr2 [file join $root vendor_reference lab1 user_source hdl_source ph1p35_ddr ddr2 src sdc ddr2.sdc]
    read_sdc -ip w128_d512_fifo [file join $root vendor_reference lab1 user_source ip_source w128_d512_fifo w128_d512_fifo.tcl]
    optimize_rtl
    optimize_gate -packarea baseline_gate.area
    legalize_phy_inst
    place
    route
    report_area -io_info -file baseline_phy.area
    update_timing -mode final
    report_timing_status -file baseline_phy.ts
    report_timing_summary -file baseline_pr.timing
    report_timing_exception -file baseline_exception.timing
    report_clock_utilization -file baseline_clocks.txt
    bitgen -bit baseline.bit
    puts "CRITICALWORK_BASELINE_COMPLETED"
} message]} {
    puts stderr "BUILD_FAILED: $message"
    puts stderr $::errorInfo
    exit 1
}
exit
