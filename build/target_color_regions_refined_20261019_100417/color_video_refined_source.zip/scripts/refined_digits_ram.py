"""Equivalent serialized BCD store for the production footer formatter."""
def transform(s,style='bram'):
    old='reg [31:0] numbers[0:31];reg [7:0] characters[0:127];'
    assert old in s
    s=s.replace(old,'''(* ram_style="STYLE" *) reg [3:0] digits[0:255];
 reg [31:0] bcd_word;reg [2:0] digit_index;reg [3:0] digit_q;
 reg [7:0] characters[0:127];''')
    s=s.replace('reg [2:0] format_state;', 'reg [3:0] format_state;')
    old="((numbers[token_data[12:8]]>>(token_data[3:0]*4)) & 4'hf)"
    assert old in s
    s=s.replace(old,"(token_data[3]?4'd0:digit_q)")
    old='format_state<=0;field_index<=0;bit_index<=0;binary<=0;decimal<=0;format_col<=0;format_row<=0;footer_ready<=0;'
    assert old in s
    s=s.replace(old,old+'bcd_word<=0;digit_index<=0;')
    old=''' if(bit_index==23)begin numbers[field_index]<={adjusted[30:0],binary[23]};
 if(field_index==31)begin format_col<=0;format_row<=0;format_state<=3;end
 else begin field_index<=field_index+1'b1;format_state<=1;end end'''
    assert old in s
    s=s.replace(old,''' if(bit_index==23)begin bcd_word<={adjusted[30:0],binary[23]};digit_index<=0;format_state<=8;end''')
    old=' 3:format_state<=4;'
    assert old in s
    s=s.replace(old,''' 8:begin bcd_word<=bcd_word>>4;
 if(digit_index==7)begin
 if(field_index==31)begin format_col<=0;format_row<=0;format_state<=3;end
 else begin field_index<=field_index+1'b1;format_state<=1;end
 end else digit_index<=digit_index+1'b1;end
 3:format_state<=4;''')
    old=' always @(posedge I_clk or negedge I_rst_n)begin'
    assert old in s
    s=s.replace(old,''' // Format states 3..7 cover the synchronous ROM and digit read latency.
 always @(posedge I_clk)begin
 digit_q<=digits[{token_data[12:8],token_data[2:0]}];
 if(format_state==8)digits[{field_index,digit_index}]<=bcd_word[3:0];
 end
 always @(posedge I_clk or negedge I_rst_n)begin''',1)
    return s.replace('ram_style="STYLE"',f'ram_style="{style}"')
