"""Private placement comparison of shallow metadata RAM vs plain registers."""
from refined_testlib import R
import sys,xml.etree.ElementTree as ET
out=R/'build/refined_store_registers_prototype';out.mkdir(exist_ok=True)
original=R/'td_project/target_color_regions_refined.al';candidate=out/'refined_frame_store.v'
text=(R/'rtl/color_regions/refined_frame_store.v').read_text(encoding='utf-8')
old='reg [MW-1:0] metadata[0:3];';assert text.count(old)==1
data=text.replace(old,'(* ram_style="none" *) '+old).encode('utf-8')
if candidate.exists():assert candidate.read_bytes()==data
else:candidate.write_bytes(data)
tree=ET.fromstring(original.read_text(encoding='utf-8').replace('&','&amp;').replace('::','__TD_COLON__'))
for node in tree.findall('./Source_Files/*/File'):
 p=(original.parent/node.attrib['Path']).resolve();node.set('Path',(candidate if p.name==candidate.name else p).as_posix())
project=out/'prototype.al';project.write_bytes(('<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(tree,encoding='unicode').replace('&amp;','&').replace('__TD_COLON__','::')+'\n').encode('utf-8'))
path=R/'scripts/run_refined_build.py';s=path.read_text(encoding='utf-8')
s=s.replace("project=R/'td_project/target_color_regions_refined.al'","project=prototype_project")
s=s.replace("f'refined_{a.stage}_{stamp}'","f'refined_store_registers_{a.stage}_{stamp}'")
sys.argv=[str(path),'--stage','place']
exec(compile(s,str(path),'exec'),dict(__file__=str(path),__name__='__main__',prototype_project=project))
