"""Independent footer pixels and private synthesis of the RAM-store candidate."""
from pathlib import Path
import argparse,sys,xml.etree.ElementTree as ET
from refined_testlib import R
from refined_digits_ram import transform

ap=argparse.ArgumentParser();ap.add_argument('--synth',action='store_true');ap.add_argument('--style',choices=['block','bram','bram_20k'],default='bram');ap.add_argument('--force',action='store_true');a=ap.parse_args()
variant=a.style+('_force' if a.force else '')
out=R/('build/refined_digits_prototype' if variant=='block' else f'build/refined_digits_{variant}_prototype');out.mkdir(exist_ok=True)
candidate=out/'refined_osd.v'
text=transform((R/'rtl/color_regions/refined_osd.v').read_text(encoding='utf-8'),a.style)
if a.force:text=text.replace(f'(* ram_style="{a.style}" *)',f'(* force_ram *) (* ram_style="{a.style}" *)')
data=text.encode('utf-8')
if candidate.exists():assert candidate.read_bytes()==data,'Preserve the previous prototype in its own directory'
else:candidate.write_bytes(data)
if not a.synth:
    path=R/'scripts/test_refined_v4_ui.py';s=path.read_text(encoding='utf-8')
    s=s.replace("run('refined_v4_ui_pixels'",f"run('digits_{variant}_ui_pixels'")
    s=s.replace("[R/'rtl/color_regions'/f'{n}.v' for n in", "[candidate if n=='refined_osd' else R/'rtl/color_regions'/f'{n}.v' for n in")
    exec(compile(s,str(path),'exec'),dict(__file__=str(path),__name__='__main__',candidate=candidate))
else:
    original=R/'td_project/target_color_regions_refined.al'
    tree=ET.fromstring(original.read_text(encoding='utf-8').replace('&','&amp;').replace('::','__TD_COLON__'))
    for node in tree.findall('./Source_Files/*/File'):
        p=(original.parent/node.attrib['Path']).resolve()
        node.set('Path',(candidate if p.name=='refined_osd.v' else p).as_posix())
    project=out/'prototype.al'
    project.write_bytes(('<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(tree,encoding='unicode').replace('&amp;','&').replace('__TD_COLON__','::')+'\n').encode('utf-8'))
    path=R/'scripts/run_refined_build.py';s=path.read_text(encoding='utf-8')
    s=s.replace("project=R/'td_project/target_color_regions_refined.al'","project=prototype_project")
    s=s.replace("f'refined_{a.stage}_{stamp}'",f"f'refined_digits_{variant}_{{a.stage}}_{{stamp}}'")
    sys.argv=[str(path),'--stage','synth']
    exec(compile(s,str(path),'exec'),dict(__file__=str(path),__name__='__main__',prototype_project=project))
