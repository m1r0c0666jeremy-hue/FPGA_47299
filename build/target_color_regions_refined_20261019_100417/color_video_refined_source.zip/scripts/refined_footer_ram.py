"""Serialize BCD and glyph storage into one project-owned synchronous ERAM."""
from refined_digits_ram import transform

def footer_ram_asset(source):
 s=transform(source)
 s=s.replace('(* ram_style="bram" *) reg [3:0] digits[0:255];','')
 s=s.replace('reg [2:0] digit_index;reg [3:0] digit_q;','reg [2:0] digit_index;wire [3:0] digit_q;')
 s=s.replace('reg [7:0] characters[0:127];','reg [5:0] footer_col;reg [4:0] footer_px;')
 s=s.replace(' reg [5:0] footer_col;reg [4:0] footer_px;\n reg [7:0] footer_glyph;', ' reg [7:0] footer_glyph;')
 old=''' always @(posedge I_clk)begin
 digit_q<=digits[{token_data[12:8],token_data[2:0]}];
 if(format_state==8)digits[{field_index,digit_index}]<=bcd_word[3:0];
 end'''
 assert old in s
 s=s.replace(old,''' wire [5:0] next_footer_col=!I_de?footer_col:x==0?6'd0:
 (x>=16 && x<16+COLS*FONT && footer_px==FONT-1)?footer_col+1'b1:footer_col;
 wire next_footer_row=(I_de && x==1279)?y>=675:y>=676;
 wire [8:0] cache_read_addr=footer_ready?{2'b10,next_footer_row,next_footer_col}:
 {1'b0,token_data[12:8],token_data[2:0]};
 wire [8:0] cache_write_addr=format_state==8?{1'b0,field_index,digit_index}:
 {2'b10,format_row,format_col};
 wire [7:0] cache_write_data=format_state==8?{4'd0,bcd_word[3:0]}:decoded_glyph;
 wire [7:0] cache_q;assign digit_q=cache_q[3:0];
 refined_footer_eram storage(I_clk,format_state==8 || format_state==7,
 cache_write_addr,cache_write_data,cache_read_addr,cache_q);''')
 s=s.replace('7:begin characters[(format_row?COLS:0)+format_col]<=decoded_glyph;', '7:begin')
 old='footer_glyph=characters[(footer_row?COLS:0)+footer_col];'
 assert old in s;s=s.replace(old,'footer_glyph=cache_q;')
 return s+ERAM

ERAM='''
// One synchronous read port; BCD occupies 0..255, glyphs occupy 256..383.
// No consumed read collides with a write. Icarus models the declared cycle
// semantics; vendor physical timing and primitive internals are not simulated.
module refined_footer_eram(input wire clk,we,input wire [8:0] wa,
 input wire [7:0] data,input wire [8:0] ra,output wire [7:0] q);
`ifdef __ICARUS__
 reg [7:0] mem[0:511];reg [7:0] read_q;
 always @(posedge clk)begin if(we)mem[wa]<=data;read_q<=mem[ra];end
 assign q=read_q;
`else
 wire [19:0] read_q;
 PH1P_LOGIC_ERAM #(.DATA_WIDTH_A(20),.DATA_WIDTH_B(20),
 .ADDR_WIDTH_A(10),.ADDR_WIDTH_B(10),.DATA_DEPTH_A(1024),.DATA_DEPTH_B(1024),
 .MODE("DP"),.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
 .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.IMPLEMENT("20K(FAST)"),
 .ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),.CLKMODE("SYNC"),
 .SSROVERCE("DISABLE"),.OREGSET_A("RESET"),.OREGSET_B("RESET"),
 .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),
 .ASYNC_RESET_RELEASE_A("SYNC"),.ASYNC_RESET_RELEASE_B("SYNC"),
 .INIT_FILE("NONE"),.FILL_ALL("NONE")) ram(
 .dia({12'd0,data}),.addra({1'b0,wa}),.cea(1'b1),.ocea(1'b0),.clka(clk),.wea(we),.rsta(1'b0),.bea(1'b0),
 .dib(20'd0),.addrb({1'b0,ra}),.ceb(1'b1),.oceb(1'b0),.clkb(clk),.web(1'b0),.rstb(1'b0),.beb(1'b0),
 .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0),.doa(),.dob(read_q),.ecc_sbiterr(),.ecc_dbiterr());
 assign q=read_q[7:0];
`endif
endmodule
'''
