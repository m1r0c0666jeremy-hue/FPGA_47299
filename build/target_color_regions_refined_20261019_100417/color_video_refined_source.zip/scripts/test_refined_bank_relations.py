"""Private bank-flag optimization: cycle equivalence and optional synthesis."""
from refined_testlib import R,run
from refined_bank_relations import pairwise_asset
import argparse,sys,xml.etree.ElementTree as ET
ap=argparse.ArgumentParser();ap.add_argument('--synth',action='store_true');ap.add_argument('--stage',choices=['synth','place'],default='synth');a=ap.parse_args()
out=R/'build/refined_bank_relations_prototype';out.mkdir(exist_ok=True)
base=R/'rtl/color_regions/refined_frame_store.v';candidate=out/base.name
data=pairwise_asset(base.read_text(encoding='utf-8')).encode('utf-8')
if candidate.exists():assert candidate.read_bytes()==data
else:candidate.write_bytes(data)
if not a.synth:
 path=R/'scripts/test_refined_store.py';s=path.read_text(encoding='utf-8')
 s=s.replace("run('store_cached_id_comparison'","run('store_pairwise_id_comparison'").replace("run('refined_v4_frame_store_and_display'","run('store_pairwise_v4_display'")
 s=s.replace("[R/'rtl/color_regions'/f'{n}.v' for n in", "[candidate if n=='refined_frame_store' else R/'rtl/color_regions'/f'{n}.v' for n in")
 exec(compile(s,str(path),'exec'),dict(__file__=str(path),__name__='__main__',candidate=candidate))
 ref=out/'reference.v';b=base.read_text(encoding='utf-8').replace('module refined_frame_store #','module reference_frame_store #').encode()
 if ref.exists():assert ref.read_bytes()==b
 else:ref.write_bytes(b)
 ports="(.I_clk(clk),.I_rst_n(rst),.I_begin(1'b0),.I_bank(2'd0),.I_frame_id(32'd0),.I_write(1'b0),.I_addr(25'd0),.I_result(1'b0),.I_meta(768'd0),.I_snapshot(1'b0),.I_command(10'd0),.I_frame_us(32'd0),.I_epoch(16'd0),.I_time_valid(1'b1),.I_invalidate(1'b0))"
 tb='''module tb;reg clk=0;always #5 clk=~clk;reg rst=0;
 reference_frame_store #(.V4(1)) old_ui PORTS;
 refined_frame_store #(.V4(1)) new_ui PORTS;
 reg [31:0] edge_values[0:11];reg [31:0] rng=32'h47299;integer n,i,j,k;
 initial begin
 edge_values[0]=0;edge_values[1]=1;edge_values[2]=32'hffffffff;edge_values[3]=32'h80000000;
 edge_values[4]=32'h7fffffff;edge_values[5]=32'h80000001;edge_values[6]=32'hffff0000;edge_values[7]=32'h10000;
 edge_values[8]=2;edge_values[9]=32'hfffffffe;edge_values[10]=32'h40000000;edge_values[11]=32'hc0000000;
 repeat(3)@(negedge clk);rst=1;
 for(n=0;n<120736;n=n+1)begin
 @(negedge clk);k=n;
 for(i=0;i<4;i=i+1)begin
 rng=rng*32'd1664525+32'd1013904223;
 old_ui.ids[i]=n<20736?edge_values[k%12]:rng;new_ui.ids[i]=old_ui.ids[i];k=k/12;
 end
 @(posedge clk);#1;
 for(i=0;i<4;i=i+1)if(old_ui.newer[i]!==new_ui.newer[i] || old_ui.predecessor[i]!==new_ui.predecessor[i])$fatal(1,"bank flag mismatch trial%0d bank%0d",n,i);
 end
 $display("BANK_PAIRWISE_FLAGS_PASS 20736 exhaustive edge combinations + 100000 random 4-bank ID sets, half-range/tie/modular wrap included");$finish;
 end endmodule'''.replace('PORTS',ports)
 run('store_pairwise_flags',tb,[ref,candidate])
else:
 original=R/'td_project/target_color_regions_refined.al'
 tree=ET.fromstring(original.read_text(encoding='utf-8').replace('&','&amp;').replace('::','__TD_COLON__'))
 for node in tree.findall('./Source_Files/*/File'):
  p=(original.parent/node.attrib['Path']).resolve();node.set('Path',(candidate if p.name==candidate.name else p).as_posix())
 project=out/'prototype.al';project.write_bytes(('<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(tree,encoding='unicode').replace('&amp;','&').replace('__TD_COLON__','::')+'\n').encode('utf-8'))
 path=R/'scripts/run_refined_build.py';s=path.read_text(encoding='utf-8').replace("project=R/'td_project/target_color_regions_refined.al'","project=prototype_project").replace("f'refined_{a.stage}_{stamp}'","f'refined_pairwise_{a.stage}_{stamp}'")
 sys.argv=[str(path),'--stage',a.stage,'--map-mode','area_prior','--pack-effort','high','--macro-performance','macro_congestion']
 exec(compile(s,str(path),'exec'),dict(__file__=str(path),__name__='__main__',prototype_project=project))
