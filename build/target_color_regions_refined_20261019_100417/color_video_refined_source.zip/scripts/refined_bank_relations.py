"""Equivalent bank relationships using one modular difference per bank pair."""
def pairwise_asset(source):
 key=' integer ai,aj;'
 assert key in source
 pairs=[(i,j) for i in range(4) for j in range(i+1,4)]
 decl='\n'.join(f' wire [31:0] delta_{i}{j}=ids[{i}]-ids[{j}];' for i,j in pairs)
 s=source.replace(key,decl+'\n'+key)
 old=''' for(ai=0;ai<4;ai=ai+1)for(aj=0;aj<4;aj=aj+1)begin
 newer[ai][aj]<=$signed(ids[ai]-ids[aj])>0;
 predecessor[ai][aj]<=ids[ai]+32'd1==ids[aj];
 end'''
 assert old in s
 rows=[" for(ai=0;ai<4;ai=ai+1)begin newer[ai][ai]<=0;predecessor[ai][ai]<=0;end"]
 for i,j in pairs:
  d=f'delta_{i}{j}'
  rows += [f' newer[{i}][{j}]<=!{d}[31] && |{d}[30:0];',f' newer[{j}][{i}]<={d}[31] && |{d}[30:0];',f' predecessor[{i}][{j}]<=&{d};',f' predecessor[{j}][{i}]<={d}==32\'d1;']
 return s.replace(old,'\n'.join(rows))
