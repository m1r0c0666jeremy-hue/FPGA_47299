"""Random full character-table equivalence to the retained footer formatter."""
from refined_testlib import R,run
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--production',action='store_true');a=ap.parse_args()
candidate=R/('rtl/color_regions/refined_osd.v' if a.production else 'build/refined_footer_eram_decl_prototype/refined_osd.v')
src='''module tb;
reg clk=0;always #5 clk=~clk;reg rst=0,de=0;reg [767:0] meta;
reg [1:0] diag;reg [2:0] zoom;reg [31:0] latency,age;reg lv;
reg [127:0] ddr,pixel;reg [38:0] recovery;reg [17:0] camera;
stable_osd old_ui(.I_clk(clk),.I_rst_n(rst),.I_vs(1'b0),.I_hs(1'b0),.I_de(de),.I_rgb(24'd0),.I_meta(meta),.I_x0(11'd0),.I_y0(10'd0),
.I_zoom(zoom),.I_mode(2'd1),.I_state(3'd3),.I_tracking(1'b1),.I_show(1'b1),.I_video_ok(1'b1),.I_pair(1'b1),.I_detection_valid(1'b1),.I_sample_valid(1'b1),
.I_rotate(1'b1),.I_diag(diag),.I_image_id(32'habcdef01),.I_geometry_commit(1'b0),.I_latency_valid(lv),.I_latency_us(latency),.I_frame_age(age),.I_ddr_diag(ddr),.I_pixel_diag(pixel),.I_recovery(recovery),.I_camera(camera));
refined_osd new_ui(.I_clk(clk),.I_rst_n(rst),.I_vs(1'b0),.I_hs(1'b0),.I_de(de),.I_rgb(24'd0),.I_meta(meta),.I_x0(11'd0),.I_y0(10'd0),
.I_zoom(zoom),.I_mode(2'd1),.I_state(3'd3),.I_tracking(1'b1),.I_show(1'b1),.I_video_ok(1'b1),.I_pair(1'b1),.I_detection_valid(1'b1),.I_sample_valid(1'b1),
.I_rotate(1'b1),.I_diag(diag),.I_image_id(32'habcdef01),.I_geometry_commit(1'b0),.I_latency_valid(lv),.I_latency_us(latency),.I_frame_age(age),.I_ddr_diag(ddr),.I_pixel_diag(pixel),.I_recovery(recovery),.I_camera(camera));
integer n,k;integer seed=89365;
always @(posedge clk)if(new_ui.format_state==7 && new_ui.cache_write_addr==new_ui.cache_read_addr)$fatal(1,"consumed read/write collision");
initial begin
for(n=0;n<256;n=n+1)begin
@(negedge clk);rst=0;de=0;repeat(3)@(negedge clk);rst=1;
for(k=0;k<24;k=k+1)meta[k*32+:32]=$random(seed);
meta[415:413]=4;meta[255]=1;meta[568]=0;
meta[567:560]=n%8<4?0:((n%5+1)<<5)|(n%13);
diag=n%4;zoom=n%5;latency=$random(seed);age=$random(seed);lv=n%2;
if(n%3==0)begin latency=n*1234;age=n;end
ddr={$random(seed),$random(seed),$random(seed),$random(seed)};
pixel={$random(seed),$random(seed),$random(seed),$random(seed)};recovery={$random(seed),$random(seed)};camera=$random(seed);
old_ui.x=0;old_ui.y=620;new_ui.x=0;new_ui.y=NEW_ROW;
de=1;@(negedge clk);de=0;repeat(2400)@(negedge clk);
if(!old_ui.footer_ready || !new_ui.footer_ready)$fatal(1,"format deadline");
for(k=0;k<128;k=k+1)if(old_ui.characters[k]!==new_ui.storage.mem[256+k])$fatal(1,"case%0d char%0d old%0d new%0d",n,k,old_ui.characters[k],new_ui.storage.mem[256+k]);
end
$display("FOOTER_FORMAT_PASS 256 random tables 32768 glyphs, all pages/calibration/error/value ranges; no consumed RAM collision");$finish;
end endmodule'''
row='625' if 'y==625' in candidate.read_text(encoding='utf-8') else '624'
mods=[candidate]+[R/'rtl/color_regions'/f'{n}.v' for n in ('stable_osd','stable_glyph_rom','stable_footer_glyph_rom','refined_footer_program_rom','stable_footer_program_rom','stable_footer_text_rom','refined_logo_rom','refined_overlay_geometry')]
run('footer_format_'+('production' if a.production else 'prototype'),src.replace('NEW_ROW',row),mods)
