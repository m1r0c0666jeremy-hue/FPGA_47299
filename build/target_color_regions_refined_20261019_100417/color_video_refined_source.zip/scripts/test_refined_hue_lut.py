"""Isolated exact hue-product lookup prototype, not wired into production."""
from refined_testlib import R,run
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--synth',action='store_true');ap.add_argument('--baseline',action='store_true');a=ap.parse_args()
out=R/'build/refined_hue_lut_prototype';out.mkdir(exist_ok=True)
s=(R/'rtl/color_regions/stable_model_lane.v').read_text(encoding='utf-8')
s=s.replace('module stable_model_lane(', 'module hue_lut_lane(')
s=s.replace('models,output reg [1:0] hit);','models,output reg [1:0] hit,output wire [7:0] chroma_addr,input wire [16:0] lut_low,lut_high);')
s=s.replace('reg [16:0] lo0,hi0,lo1,hi1,h2;','reg [16:0] lo1,hi1,h2;wire [16:0] lo0=lut_low,hi0=lut_high;assign chroma_addr=d;')
s=s.replace('lo0<=0;hi0<=0;','').replace(' lo0<=c1[62:54]*d;hi0<=c1[53:45]*d;\n','')
assert 'lo0<=' not in s and 'assign chroma_addr=d;' in s
s+='\n'+(R/'scripts/refined_hue_lut.v.txt').read_text(encoding='utf-8')
candidate=out/'hue_lut.v';b=s.encode('utf-8')
if candidate.exists():assert candidate.read_bytes()==b
else:candidate.write_bytes(b)
baseline=out/'baseline.v';b='''module hue_old_pair(input wire clk,rst_n,valid,input wire [23:0] rgb0,rgb1,input wire [127:0] models,
output wire ready,out_valid,output wire [1:0] hit0,hit1);
wire [1:0] a,b;reg [3:0] vp;assign ready=1;
stable_model_lane c0(clk,rst_n,rgb0,models,a),c1(clk,rst_n,rgb1,models,b);
always @(posedge clk or negedge rst_n)if(!rst_n)vp<=0;else vp<={vp[2:0],valid};
assign out_valid=vp[3];assign hit0=out_valid?a:2'd0;assign hit1=out_valid?b:2'd0;endmodule
'''.encode()
if baseline.exists():assert baseline.read_bytes()==b
else:baseline.write_bytes(b)
if not a.synth:
 tb='''module tb;
reg clk=0;always #5 clk=~clk;reg rst=0,valid=0;reg [23:0] rgb0=0,rgb1=0;reg [127:0] models=0;
wire ready,ov;wire [1:0] a,b,ga,gb;
hue_lut_pair dut(clk,rst,valid,rgb0,rgb1,models,ready,ov,a,b);
stable_model_lane old0(clk,rst,rgb0,models,ga),old1(clk,rst,rgb1,models,gb);
reg [3:0] expected_v=0;reg [31:0] rng=32'h47299;integer n,k,checks=0,stalled=0,dual=0;
function [63:0] model(input integer lo,hi,m,d,s,v);begin model=0;model[63]=v;model[62:54]=lo;model[53:45]=hi;model[44:37]=m;model[36:29]=d;model[28:27]=s;end endfunction
always @(posedge clk)begin
if(!rst)expected_v<=0;else expected_v<={expected_v[2:0],valid && ready};
#1;if(ov!==expected_v[3])$fatal(1,"valid latency");
if(ov)begin if(a!==ga || b!==gb)$fatal(1,"lookup mismatch n%0d k%0d a%b/%b b%b/%b",n,k,a,ga,b,gb);checks=checks+2;if(a==3 || b==3)dual=dual+1;end
end
initial begin repeat(4)@(negedge clk);rst=1;
for(n=0;n<64;n=n+1)begin
@(negedge clk);
case(n%8)
0:models={model(195,255,32,16,1,1),model(345,30,32,16,1,1)};
1:models={model(255,330,24,8,0,1),model(45,75,24,8,0,1)};
2:models={model(0,360,0,1,0,1),model(0,360,0,1,0,1)};
3:models={model(511,1,0,1,3,1),model(511,0,0,1,2,1)};
4:models={model(20,200,0,1,0,1),model(0,511,255,255,3,1)};
5:models={model(300,60,32,8,0,1),model(0,0,0,0,0,0)};
default:begin rng=rng*1664525+1013904223;models={model(rng[8:0],rng[17:9],rng[25:18],8,0,1),model(rng[17:9],rng[8:0],24,8,n%4,1)};end
endcase
for(k=0;k<640;k=k+1)begin
@(negedge clk);rng=rng*1664525+1013904223;rgb0=rng[23:0];rng=rng*1664525+1013904223;rgb1=rng[23:0];valid=k%11!=0;
if(k%17==0)begin rgb0=24'h808080;rgb1=24'hff0000;end
if(k%19==0)begin rgb0=24'h0000ff;rgb1=24'hffff00;end
if(k>270 && !ready)$fatal(1,"configuration did not settle");if(valid && !ready)stalled=stalled+1;
end
end
// Repeated interrupted builds and disabled-A profiles must preserve B results.
for(n=0;n<2048;n=n+1)begin @(negedge clk);rng=rng*1664525+1013904223;
models={model(0,360,0,1,0,1),model(rng[8:0],rng[17:9],0,1,0,0)};rgb0=rng[23:0];rgb1=~rng[23:0];valid=1;end
@(negedge clk);valid=0;repeat(8)@(negedge clk);
if(checks<40000 || dual<100 || stalled<1000)$fatal(1,"weak coverage %0d %0d %0d",checks,dual,stalled);
$display("HUE_LUT_MATH_PASS %0d accepted pixels, dual hits%0d, config bubbles%0d; generic/wrapped/511 bounds, neutral/bright/dark and interrupted updates",checks,dual,stalled);$finish;
end endmodule'''
 run('hue_lut_math',tb,[R/'rtl/color_regions/stable_model_lane.v',candidate])
else:
 stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');dest=R/'build'/f'hue_lut_unit_{"old" if a.baseline else "new"}_{stamp}';dest.mkdir(exist_ok=False)
 top='hue_old_pair' if a.baseline else 'hue_lut_pair'
 files=[R/'rtl/color_regions/stable_model_lane.v',baseline] if a.baseline else [candidate]
 before={f.relative_to(R).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
 script=dest/'run.tcl';script.write_text('''if {[catch {
import_device ph1_35p.db -package PH1P35MDG324 -speed 3
set_param flow syn_ip_flow ip
'''+f'read_hdl -file {{'+ ' '.join(p.as_posix() for p in files)+f'}} -top {top}\n'+'''
optimize_rtl
optimize_gate -packarea area.rpt
puts "HUE_UNIT_SYNTH_PASS"
} message]} {puts stderr "BUILD_FAILED: $message";puts stderr $::errorInfo;exit 1}
exit
''',encoding='utf-8')
 td=Path('D:/26_software/TangDynasty/bin/td_commands_prompt.exe');env=os.environ.copy();env['PATH']=str(td.parent)+os.pathsep+env.get('PATH','')
 print('HUE_UNIT_ATTEMPT',dest,flush=True)
 with (dest/'td.log').open('w',encoding='utf-8') as f:p=subprocess.run([str(td),script.as_posix()],cwd=dest,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert before=={f.relative_to(R).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
 (dest/'inputs.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
 print('HUE_UNIT_SYNTH_EXIT',p.returncode,flush=True)
 passed=p.returncode==0 and (dest/'area.rpt').is_file() and 'HUE_UNIT_SYNTH_PASS' in (dest/'td.log').read_text(encoding='utf-8')
 (dest/'summary.json').write_text(json.dumps(dict(exit_code=p.returncode,passed=passed,scope='unit resource mapping only; no physical timing validation'),indent=2),encoding='utf-8')
 if not passed:raise SystemExit(p.returncode or 3)
