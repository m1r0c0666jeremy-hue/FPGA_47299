"""Independent integer references. No camera samples are bundled with this file.

Hits use the diagnostic RTL bit order: red=8, blue=4, yellow=2, purple=1.
YCbCr coefficients follow the teacher's limited-range, scale-256 conversion.
"""
from itertools import combinations

COLORS=('red','blue','yellow','purple')
COMPONENTS=('y','cb','cr')
BITS=dict(zip(COLORS,(8,4,2,1)))

def rgb_to_ycbcr(r,g,b):
    if not all(type(v) is int and 0<=v<=255 for v in (r,g,b)):
        raise ValueError('RGB channels must be integers in 0..255.')
    return ((47*r+157*g+16*b+4096)>>8,
            (112*b-26*r-86*g+32768)>>8,
            (112*r-102*g-10*b+32768)>>8)

def old_rgb_hits(r,g,b,cfg):
    rgb_to_ycbcr(r,g,b)  # Validate the input independently of the classifier.
    def dominant(v,a,z):
        return (v>=cfg['color_min'] and v>=a+cfg['color_diff'] and v>=z+cfg['color_diff']
                and v*cfg['ratio_den']>=a*cfg['ratio_num'] and v*cfg['ratio_den']>=z*cfg['ratio_num'])
    def dual(a,z,other):
        lo,hi=min(a,z),max(a,z)
        return (lo>=cfg['yp_min'] and lo>=other+cfg['yp_diff']
                and lo*cfg['yp_ratio_den']>=other*cfg['yp_ratio_num'] and hi<=lo*cfg['yp_balance'])
    return (8*dominant(r,g,b)|4*dominant(b,g,r)|2*dual(r,g,b)|dual(r,b,g))

def window(cfg,color):
    return tuple((cfg[f'ycbcr_{color}_{axis}_min'],cfg[f'ycbcr_{color}_{axis}_max']) for axis in COMPONENTS)

def validate_windows(cfg,allow_disabled=False,reject_overlap=True):
    boxes={}
    for color in COLORS:
        bounds=window(cfg,color)
        if not all(type(v) is int and 0<=v<=255 for pair in bounds for v in pair):
            raise ValueError(f'{color}: bounds must be integers in 0..255.')
        if any(lo>hi for lo,hi in bounds):
            if not allow_disabled:raise ValueError(f'{color}: disabled or inverted window.')
        else:boxes[color]=bounds
    if reject_overlap:
        for a,b in combinations(boxes,2):
            if boxes_intersect(boxes[a],boxes[b]):raise ValueError(f'Overlapping color windows: {a}/{b}.')
    return boxes

def boxes_intersect(a,b):
    return all(max(alo,blo)<=min(ahi,bhi) for (alo,ahi),(blo,bhi) in zip(a,b))

def ycbcr_hits(y,cb,cr,cfg):
    if not all(type(v) is int and 0<=v<=255 for v in (y,cb,cr)):
        raise ValueError('YCbCr channels must be integers in 0..255.')
    raw=0
    for color in COLORS:
        if all(lo<=value<=hi for value,(lo,hi) in zip((y,cb,cr),window(cfg,color))):raw|=BITS[color]
    ambiguous=bool(raw and raw&(raw-1))
    return (0 if ambiguous else raw),ambiguous

def rtl_window_parameters(cfg):
    validate_windows(cfg)
    lines=['// Independent calibrated candidate. Not connected to production RTL.',
           '// Apply only after hardware validation and an explicit integration step.']
    for color in COLORS:
        for axis in COMPONENTS:
            for edge in ('min','max'):
                key=f'ycbcr_{color}_{axis}_{edge}'
                lines.append(f'localparam integer {color.upper()}_{axis.upper()}_{edge.upper()} = {cfg[key]};')
    return '\n'.join(lines)+'\n'
